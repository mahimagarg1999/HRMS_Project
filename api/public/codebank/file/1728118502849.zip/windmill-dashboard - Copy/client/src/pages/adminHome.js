import React from 'react';
import Nav from '../components/Navbar/navbar';

const AdminHome = () => {
    return (

        <div>
            <Nav />
            <img src="https://beehivesoftware.in/wp-content/uploads/2023/07/admin-1.jpg" alt="Your Image" style={{ width: '100%', height: 'auto' }} />

        </div>
    );
}

export default AdminHome;